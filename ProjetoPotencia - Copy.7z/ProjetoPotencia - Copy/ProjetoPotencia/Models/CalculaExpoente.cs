﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc.Formatters;

namespace ProjetoPotencia.Models
{
    public class CalculaExpoente
    {
        public int valor;
        public int inexpo;
        public int Result;
        public int Calculo(int valor1, int inexpo)
        {
            int Result = Convert.ToInt32(Math.Pow(valor1, inexpo));

            return Result;
        }
    }
}

